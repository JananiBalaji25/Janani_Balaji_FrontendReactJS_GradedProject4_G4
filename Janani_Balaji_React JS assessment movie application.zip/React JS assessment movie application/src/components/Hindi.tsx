import TopIndian from "./IndianMovies/TopIndian";

const Hindi = () => {
    return ( 
        <div>
            <TopIndian />
        </div>
     );
}
 
export default Hindi;