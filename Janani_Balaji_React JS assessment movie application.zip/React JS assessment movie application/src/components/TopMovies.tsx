import TopRatedMovies from "./TopMovies/TopRatedMovies";

const TopMovies = () => {
    return ( 
        <div>
            <TopRatedMovies />
        </div>
     );
}
 
export default TopMovies;